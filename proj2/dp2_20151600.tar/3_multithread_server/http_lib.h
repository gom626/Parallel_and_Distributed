//
// Created by taeguk on 2016-11-29.
//

#ifndef DIST_PROG_ASSIGNMENT_HTTP_LIB_H
#define DIST_PROG_ASSIGNMENT_HTTP_LIB_H

// Very Dangerous. Just for homework.
int process_request(const char* request, int fd);

#endif //DIST_PROG_ASSIGNMENT_HTTP_LIB_H
