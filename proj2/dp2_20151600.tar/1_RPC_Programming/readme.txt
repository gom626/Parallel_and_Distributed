서버 돌리는 법
./rand_server.c


client 돌리는 법
./rand_client 127.0.0.1
ex)
3+5
4*3
--기능구현 ......
--한가지 연산자 밖에 안 돌아갑니다.--
